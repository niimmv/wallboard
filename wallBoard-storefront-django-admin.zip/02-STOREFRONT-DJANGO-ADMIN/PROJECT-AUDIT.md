# wallBoard Storefront-only Release Audit

- Red token: `#FF636C` exactly.
- Warm cream surfaces, charcoal linework and retro illustration identity retained.
- Persian font: Vazirmatn (400–700), Latin accent: Caveat.
- Framed 3-slide home hero; 5-second autoplay.
- Responsive layouts with mobile two-column product grid and narrow-screen fallback.
- Product card content limited to image, title, price and actions.
- Product details use centralized product data and slug lookup.
- No custom admin source or output is included; production management is Django Admin.
- API routes are proposals; Django backend is not part of this package.
- SEO handoff docs included; canonical/sitemap/schema require the final production domain and server rendering.
