# Proposed API Contract — wallBoard /api/v1

> This is a handoff proposal. These routes do not exist until the Django team implements them.

## Conventions

- JSON over HTTPS.
- UTF-8.
- DRF pagination: `{ "count": 0, "next": null, "previous": null, "results": [] }`.
- Errors should use DRF's standard field errors or `{ "detail": "..." }`.
- Prices are integer minor units or decimal strings; choose one convention and document it. The current UI formats confirmed integer values as تومان, so do not mix ریال and تومان silently.
- IDs are immutable; public routes use unique `slug` values.

## Catalog

### `GET /products/`

Query parameters: `category`, `search`, `ordering` (`price`, `-price`, `name`), `availability`, `page`, `page_size`.

Product fields: `id`, `slug`, `sku`, `name`, `summary`, `description`, `category`, `category_name`, `price`, `compare_at_price`, `currency`, `stock_quantity`, `stock_status`, `status`, `images`, `specifications`, `compatibility`, `seo`.

### `GET /products/{slug}/`

Return one product including the full image gallery, specs, compatibility, package contents and SEO fields.

### `GET /categories/` and `GET /categories/{slug}/`

Return category name, slug, description, image and product count.

### `GET /banners/?placement=home`

Return active, scheduled home slides ordered by `sort_order`. Each slide: `id`, `title`, `accent_text`, `cta_label`, `cta_url`, `desktop_image`, `mobile_image`, `alt`, `starts_at`, `ends_at`.

## Authentication and customer data

- `POST /auth/register/`
- `POST /auth/login/`
- `POST /auth/logout/`
- `GET /users/me/`
- `GET|POST /users/me/addresses/`
- `PATCH|DELETE /users/me/addresses/{id}/`

Use Django session cookies and CSRF. Do not return reusable secrets to JavaScript.

## Cart and wishlist

- `GET /cart/`
- `PUT /cart/` with `{ "items": [{ "product_id": "...", "quantity": 1 }] }`
- `GET /wishlist/`
- `PUT /wishlist/` with `{ "product_ids": ["..."] }`

Server responses must include authoritative current product prices and availability. The client must not be trusted for totals.

## Orders and payment

- `POST /orders/` — validate cart, shipping address and inventory; return order summary and payment state.
- `GET /orders/`
- `GET /orders/{order_number}/`
- `POST /payments/initialize/` with `{ "order_id": "..." }`
- Gateway callback/verification endpoints must be server-only and verify the provider response.

Never accept a client-provided total as the amount to charge.

## Contact and reviews (optional)

- `POST /contact-messages/`
- `GET /products/{slug}/reviews/`
- `POST /products/{slug}/reviews/` (authenticated, moderation required)

## Example product response

```json
{
  "id": "panel-30",
  "slug": "pegboard-panel-30x30",
  "sku": "WB-PNL-3030",
  "name": "پنل پگ‌برد ۳۰×۳۰",
  "summary": "پنل اصلی از PVC سفید، ضخامت ۸ میلی‌متر، برش CNC.",
  "price": null,
  "currency": "IRT",
  "stock_quantity": null,
  "stock_status": "unconfirmed",
  "images": [],
  "specifications": [
    { "label": "ابعاد", "value": "۳۰ × ۳۰ سانتی‌متر" },
    { "label": "جنس", "value": "PVC سفید" },
    { "label": "ضخامت", "value": "۸ میلی‌متر" },
    { "label": "روش ساخت", "value": "برش CNC" }
  ]
}
```

The sample deliberately leaves price, stock and images empty until they are confirmed.
