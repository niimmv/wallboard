# Release QA Report

## Completed checks

- Static page/link/resource validation: PASS.
- HTML doctype, Persian language, RTL and image alt validation: PASS.
- JavaScript syntax (`node --check`) for source modules and standalone bundles: PASS.
- CSS parsing for all project stylesheets: PASS.
- Node smoke tests for catalog fixtures, stable product slugs, cart, favorites, Django API query/CSRF contract: PASS.
- Distribution integrity: PASS — admin preview package contains admin page and bundle; storefront-only package contains neither.
- Main brand token verified as `#FF636C` in both distributions.

## Not completed in this build environment

- Vite production build and ESLint/Vitest: dependencies are not installed in this offline environment.
- Playwright browser E2E and visual viewport capture: local browser execution is restricted in this environment.
- Lighthouse and real-device Core Web Vitals: must be run after deployment or on the developer workstation.
- Django API integration, authentication, payment and server-rendered SEO: backend does not exist in this frontend package.

## Required before production

Run the commands in `developer-source/README.md`, execute `npm run test:e2e`, test the specified viewport widths, run Lighthouse mobile/desktop, and complete the Django/SEO checklist in the handoff documents.
