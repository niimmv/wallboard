# Django Backend Handoff — wallBoard

## 1. Integration principle

The frontend is a Persian RTL multi-page storefront. Keep the existing visual system and use Django as the source of truth for catalog, prices, stock, users, carts, orders, payment state and content. Do not treat browser storage or submitted prices as authoritative.

## 2. Recommended deployment shape

- Django + Django REST Framework serves `/api/v1/`.
- Django serves SEO-critical product/category pages as server-rendered HTML (or a carefully implemented SSR layer) so titles, canonical URLs, descriptions and structured data exist in the initial response.
- Run `npm run build` and serve the Vite `developer-source/dist/` output as the static root. Static assets are served from a CDN or Nginx with hashed asset filenames and long-lived immutable caching. The `site/` folder is only the zero-dependency local preview.
- User-facing session authentication should use secure HttpOnly cookies and Django CSRF protection. Do not store access tokens or passwords in localStorage.
- Media files are uploaded and managed by Django; the frontend receives absolute or same-origin media URLs from the API.

## 3. Two frontend distributions

### A — with custom wallBoard admin preview

`src/admin/` and `/admin/index.html` are a browser-local UI prototype. It stores sample data in localStorage and is **not an authentication or authorization boundary**. Do not expose it as a production admin. If the team wants a custom dashboard later, build it as a protected Django-backed application with server-side permissions.

### B — storefront only (recommended for production)

The custom admin page, admin scripts and admin styles are removed. Use Django's built-in Admin for products, categories, inventory, orders, users, banners and media. Configure `/admin/` to route to Django, not to the static frontend.

## 4. Product model

Suggested fields:

- `id`: immutable database ID
- `slug`: unique public URL slug
- `sku`: unique internal product code
- `name`, `short_description`, `description`
- `category`: foreign key / slug
- `price`, `compare_at_price`: decimal, nullable until confirmed
- `currency`: `IRR` or `IRT` by an explicit business decision; UI currently displays تومان
- `stock_quantity`, `stock_status`, `is_active`
- `images`: ordered related media records with `url`, `alt`, `width`, `height`, `is_primary`
- `specifications`: structured key/value list
- `compatibility`: explicit accessory compatibility relations
- `seo_title`, `seo_description`, `canonical_path`, `og_image`

Never infer load capacity, compatibility, dimensions or kit contents from illustrations. Only publish facts approved by the business owner. The currently confirmed main panel facts are PVC white, 30×30 cm, 8 mm, CNC cut.

## 5. API adapter

`src/services/django-api.js` exposes a proposed DRF adapter. The routes are suggestions, not existing endpoints. Match the response envelope and field names with the backend team before wiring UI calls.

Recommended routes and payload shapes are in `API-CONTRACT.md`.

## 6. Cart and checkout rules

- Browser cart may temporarily store `{product_id, quantity}` only.
- Backend must re-fetch prices, validate stock, calculate shipping, discounts and final totals.
- The client must never set the payable total.
- Order creation should return a server-generated order number and authoritative line items.
- Payment initiation, verification, callback/webhook and secret credentials remain server-side.
- Do not show an order as paid until the server verifies the gateway callback.

## 7. Authentication and security

- Use Django session auth with `Secure`, `HttpOnly`, `SameSite` cookies where deployment permits.
- Return and validate CSRF tokens for unsafe methods.
- Apply server-side permission checks to all admin and customer endpoints.
- Rate-limit login, registration, contact forms and payment-initiation endpoints.
- Validate image uploads (MIME, size, dimensions), sanitize filenames and store outside executable paths.
- Add audit logs for admin changes and order status transitions.

## 8. Content and hero banners

Model homepage slides as records with `title`, `accent_text`, `cta_label`, `cta_url`, `desktop_image`, `mobile_image`, `alt`, `sort_order`, `starts_at`, `ends_at`, `is_active`. The current frontend preview has three authored slides and rotates every five seconds. Production content should be returned by `/api/v1/banners/?placement=home` and respect schedule/timezone on the server.

## 9. Integration checklist

- [ ] Confirm final domain, HTTPS and same-origin `/api/` routing.
- [ ] Confirm product IDs/slugs and data schema.
- [ ] Confirm real prices, stock and all product/package contents.
- [ ] Confirm accessory compatibility and load limits.
- [ ] Implement session login/register/logout and CSRF.
- [ ] Implement authoritative cart/order/discount/shipping calculations.
- [ ] Integrate payment gateway on server only.
- [ ] Configure Django Admin roles, permissions and audit logs.
- [ ] Add media upload and image variants (WebP/AVIF).
- [ ] Server-render canonical product/category pages and JSON-LD.
- [ ] Run integration, security, accessibility and performance tests before launch.
