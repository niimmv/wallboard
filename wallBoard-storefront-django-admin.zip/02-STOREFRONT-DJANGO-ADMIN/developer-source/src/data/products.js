/* Catalog fixtures derived from confirmed wallBoard specifications. */
export const defaultProducts = [
  {
    "id": "panel-30",
    "slug": "pegboard-panel-30x30",
    "sku": "WB-PNL-3030",
    "name": "پنل پگ‌برد ۳۰×۳۰",
    "category": "panels",
    "categoryName": "پنل اصلی",
    "color": "coral",
    "label": "THE ORIGINAL",
    "price": null,
    "stock": null,
    "status": "draft",
    "summary": "پنل اصلی از PVC سفید، ضخامت ۸ میلی‌متر، برش CNC.",
    "specs": [
      "ابعاد اسمی: ۳۰ × ۳۰ سانتی‌متر",
      "جنس: PVC سفید",
      "ضخامت: ۸ میلی‌متر",
      "روش ساخت: برش CNC"
    ],
    "art": "board",
    "image": null,
    "images": []
  },
  {
    "id": "shelf-30",
    "slug": "pegboard-shelf-12x30",
    "sku": "WB-SHF-1230",
    "name": "شلف پگ‌برد",
    "category": "accessories",
    "categoryName": "متعلقات",
    "color": "sand",
    "label": "SHELF",
    "price": null,
    "stock": null,
    "status": "draft",
    "summary": "شلف با ابعاد تقریبی ۱۲×۳۰ سانتی‌متر؛ برای قرارگرفتن روی نگهدارنده‌های بزرگ.",
    "specs": [
      "ابعاد تقریبی: ۱۲ × ۳۰ سانتی‌متر",
      "نیازمند نگهدارنده‌های بزرگ",
      "ظرفیت بار: تأیید نشده"
    ],
    "art": "shelf",
    "image": null,
    "images": []
  },
  {
    "id": "holders",
    "slug": "pegboard-holders-set",
    "sku": "WB-HLD-SET",
    "name": "نگهدارنده‌های پگ‌برد",
    "category": "accessories",
    "categoryName": "متعلقات",
    "color": "yellow",
    "label": "HOLDERS",
    "price": null,
    "stock": null,
    "status": "draft",
    "summary": "نگهدارنده‌های کوچک، متوسط و بزرگ برای ترکیب با پنل.",
    "specs": [
      "سه اندازه: کوچک، متوسط، بزرگ",
      "هندسه و ظرفیت وزن: تأیید نشده",
      "سازگاری نهایی نیازمند بررسی فایل تولید"
    ],
    "art": "holders",
    "image": null,
    "images": []
  },
  {
    "id": "desktop-stands",
    "slug": "pegboard-desktop-stands",
    "sku": "WB-DESK-2",
    "name": "پایه رومیزی",
    "category": "accessories",
    "categoryName": "متعلقات",
    "color": "pink",
    "label": "DESK SETUP",
    "price": null,
    "stock": null,
    "status": "draft",
    "summary": "نگهدارنده‌های استفاده از پنل روی سطح میز؛ ابعاد و روش اتصال باید تأیید شوند.",
    "specs": [
      "نوع: پایه رومیزی پنل",
      "در فهرست کیت: ۲ عدد",
      "ابعاد و پایداری نهایی: نیازمند بررسی"
    ],
    "art": "stand",
    "image": null,
    "images": []
  },
  {
    "id": "brackets",
    "slug": "pegboard-keyboard-brackets",
    "sku": "WB-BRK-3",
    "name": "براکت نگهدارنده",
    "category": "accessories",
    "categoryName": "متعلقات",
    "color": "sand",
    "label": "BRACKETS",
    "price": null,
    "stock": null,
    "status": "draft",
    "summary": "براکت‌های موجود در فهرست کیت برای نگهدارنده‌ای مانند سینی کیبورد.",
    "specs": [
      "در فهرست کیت: ۳ عدد",
      "کاربرد نهایی و هندسه: نیازمند تأیید",
      "بار مجاز: هنوز مشخص نشده"
    ],
    "art": "holders",
    "image": null,
    "images": []
  },
  {
    "id": "full-kit",
    "slug": "pegboard-complete-kit",
    "sku": "WB-KIT-01",
    "name": "کیت کامل پگ‌برد",
    "category": "kits",
    "categoryName": "ست کامل",
    "color": "dark",
    "label": "FULL SET",
    "price": null,
    "stock": null,
    "status": "draft",
    "summary": "ترکیب قطعات اعلام‌شده شامل یک پنل اصلی و متعلقات فهرست‌شده؛ بسته‌بندی تجاری نهایی در انتظار تأیید.",
    "specs": [
      "۱ پنل اصلی ۳۰×۳۰",
      "۶ نگهدارنده کوچک + ۲ متوسط + ۲ بزرگ",
      "۱ شلف حدود ۱۲×۳۰",
      "۳ براکت + ۲ پایه رومیزی",
      "ترکیب نهایی پکیج نیازمند تأیید"
    ],
    "art": "board",
    "image": null,
    "images": []
  }
];
