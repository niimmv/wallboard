import { defaultProducts } from '../data/products.js';
import { readStorage, storageKeys, writeStorage } from '../lib/storage.js';

const validCategories = new Set(['panels', 'accessories', 'kits']);
const validArtwork = new Set(['board', 'holders', 'shelf', 'stand']);
const validColors = new Set(['coral', 'sand', 'yellow', 'pink', 'dark']);

function validImagePath(value) {
  return typeof value === 'string'
    && /^\/images\/[\w./-]+$/.test(value)
    && !value.includes('..');
}

function normalizedProduct(product) {
  if (!product || typeof product.id !== 'string' || !/^[\w-]{2,60}$/.test(product.id)) {
    return null;
  }

  if (typeof product.name !== 'string' || product.name.trim().length < 2) {
    return null;
  }

  const priceValue = product.price === '' || product.price == null
    ? null
    : Number(product.price);
  const stockValue = product.stock === '' || product.stock == null
    ? null
    : Number(product.stock);

  return {
    id: product.id,
    slug: typeof product.slug === 'string' && /^[a-z0-9-]{2,100}$/.test(product.slug) ? product.slug : product.id,
    sku: String(product.sku || product.id).slice(0, 80),
    name: product.name.slice(0, 120),
    category: validCategories.has(product.category) ? product.category : 'accessories',
    categoryName: String(product.categoryName || 'متعلقات').slice(0, 80),
    color: validColors.has(product.color) ? product.color : 'sand',
    label: String(product.label || 'WALLBOARD').slice(0, 60),
    price: Number.isSafeInteger(priceValue) && priceValue >= 0 ? priceValue : null,
    stock: Number.isSafeInteger(stockValue) && stockValue >= 0 ? stockValue : null,
    status: ['draft', 'active', 'archived'].includes(product.status)
      ? product.status
      : 'draft',
    summary: String(product.summary || '').slice(0, 500),
    specs: Array.isArray(product.specs)
      ? product.specs.filter((spec) => typeof spec === 'string').slice(0, 16)
      : [],
    art: validArtwork.has(product.art) ? product.art : 'board',
    image: validImagePath(product.image) ? product.image : null,
    images: Array.isArray(product.images)
      ? product.images.slice(0, 12).filter(validImagePath)
      : [],
  };
}

export function listProducts() {
  const saved = readStorage(storageKeys.products, null);
  const source = Array.isArray(saved) ? saved : defaultProducts;
  const categoryRecords = readStorage(storageKeys.categories, []);
  const names = Array.isArray(categoryRecords)
    ? new Map(categoryRecords.map((item) => [item.id, item.name]))
    : new Map();

  return source.map(normalizedProduct).filter(Boolean).map((product) => ({
    ...product,
    categoryName: String(names.get(product.category) || product.categoryName),
  }));
}

export function getProduct(id) {
  return listProducts().find((product) => product.id === id || product.slug === id) || null;
}

export function saveProducts(products) {
  if (!Array.isArray(products)) {
    return false;
  }

  const cleaned = products.map(normalizedProduct).filter(Boolean);
  const unique = new Set(cleaned.map((product) => product.id));

  if (cleaned.length !== products.length || unique.size !== cleaned.length) {
    return false;
  }

  return writeStorage(storageKeys.products, cleaned);
}

export function resetProducts() {
  return writeStorage(storageKeys.products, defaultProducts);
}
