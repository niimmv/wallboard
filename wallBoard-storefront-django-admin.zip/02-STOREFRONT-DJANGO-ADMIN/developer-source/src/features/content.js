import { select } from '../lib/dom.js';
import { readStorage, storageKeys } from '../lib/storage.js';

/** Apply only explicitly published local admin content. Text is never treated as HTML. */
export function applyLocalContent() {
  const items = readStorage(storageKeys.content, []);

  if (!Array.isArray(items)) {
    return;
  }

  const published = items.filter((item) => item?.status === 'نمایش محلی');
  const headline = published.find((item) => item.id === 'hero-title');

  if (!headline?.body || typeof headline.body !== 'string') {
    return;
  }

  const title = select('.hero-slide--coral h1');
  if (!title) {
    return;
  }

  // Retain the editorial two-line treatment when published from admin.
  const parts = headline.body.split(/،|\n/).map((part) => part.trim()).filter(Boolean);
  const emphasized = document.createElement('em');
  emphasized.textContent = parts.slice(1).join('، ') || parts[0];
  title.replaceChildren();

  if (parts.length > 1) {
    title.append(document.createTextNode(parts[0] + '،'));
    title.append(document.createElement('br'));
  }

  title.append(emphasized);
}
