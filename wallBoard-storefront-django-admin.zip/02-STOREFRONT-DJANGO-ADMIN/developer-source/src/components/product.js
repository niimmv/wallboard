import { escapeHtml } from '../lib/dom.js';
import { priceText } from '../lib/format.js';
import { getFavorites } from '../services/favorites.js';

/**
 * Public media paths are stored as /images/file.webp in catalog data.
 * Resolve against the real favicon folder so both the Vite source project and
 * the independent offline build can use exactly the same product records.
 */
export function imageUrl(path) {
  if (typeof path !== 'string' || !/^\/images\/[\w./-]+$/.test(path) || path.includes('..')) {
    return null;
  }

  const favicon = document.querySelector('link[rel="icon"]');
  if (!favicon) {
    return null;
  }

  return new URL(path.slice('/images/'.length), new URL('.', favicon.href)).href;
}

export function productPhotos(product) {
  const candidates = Array.isArray(product.images) && product.images.length
    ? product.images
    : product.image ? [product.image] : [];

  return candidates.map((image) => {
    const source = typeof image === 'string' ? image : image?.src;
    const url = imageUrl(source);
    const alt = typeof image === 'object' ? image?.alt : '';

    return url ? { url, alt: alt || product.name } : null;
  }).filter(Boolean);
}

/** Product illustrations are intentional fallbacks, not actual CNC renders. */
export function productArt(product, { eager = false, photoIndex = 0 } = {}) {
  const image = productPhotos(product)[photoIndex];

  if (image) {
    return `
      <div class="product-art ${escapeHtml(product.color)} product-art--photo">
        <img
          src="${escapeHtml(image.url)}"
          alt="${escapeHtml(image.alt)}"
          loading="${eager ? 'eager' : 'lazy'}"
          decoding="async"
          fetchpriority="${eager ? 'high' : 'auto'}"
          data-product-image
          data-product-id="${escapeHtml(product.id)}"
          width="720"
          height="720"
        >
      </div>
    `;
  }

  const concepts = {
    board: `
      <div class="product-board">
        <div class="product-slots"></div>
        <span class="product-shelf"></span>
        <span class="product-sticky">W✳B</span>
      </div>
    `,
    shelf: '<div class="object-shelf"><span></span><i></i><i></i></div>',
    holders: '<div class="object-holders"><i></i><i></i><i></i></div>',
    stand: '<div class="object-stands"><i></i><i></i></div>',
  };

  return `
    <div
      class="product-art ${escapeHtml(product.color)}"
      role="img"
      aria-label="تصویرسازی مفهومی؛ هندسه واقعی قطعه نیست"
    >
      ${concepts[product.art] || concepts.board}
      <span class="concept-label">CONCEPT ART ✳</span>
    </div>
  `;
}

/** Cards carry only photo, title, price, and useful actions. */
export function productCard(product) {
  const favorite = getFavorites().includes(product.id);
  const url = `product.html?slug=${encodeURIComponent(product.slug || product.id)}`;
  const name = escapeHtml(product.name);
  const id = escapeHtml(product.id);

  return `
    <article class="product-card">
      <div class="product-visual">
        <a href="${url}" aria-label="مشاهده جزئیات ${name}">
          ${productArt(product)}
        </a>
        <button
          class="favorite-toggle ${favorite ? 'is-favorite' : ''}"
          type="button"
          data-favorite="${id}"
          aria-label="${favorite ? 'حذف از' : 'افزودن به'} علاقه‌مندی‌ها"
          aria-pressed="${favorite}"
        >${favorite ? '♥' : '♡'}</button>
      </div>
      <div class="product-card__details">
        <h3><a href="${url}">${name}</a></h3>
        <strong class="product-card__price">${priceText(product)}</strong>
      </div>
      <div class="product-actions">
        <a class="outline-button" href="${url}">مشاهده جزئیات ↗</a>
        <button
          class="mini-add"
          type="button"
          data-add="${id}"
          aria-label="افزودن ${name} به سبد انتخاب‌ها"
        >+</button>
      </div>
    </article>
  `;
}

export function renderProductGrid(element, products) {
  if (!element) {
    return;
  }

  element.innerHTML = products.length
    ? products.map(productCard).join('')
    : '<p class="empty-state">محصولی با این مشخصات پیدا نشد.</p>';
}
