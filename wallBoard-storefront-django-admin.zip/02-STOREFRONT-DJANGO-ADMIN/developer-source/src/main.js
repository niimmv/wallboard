import { initializeStorefront } from './features/storefront.js';
import { applyLocalContent } from './features/content.js';
import { enableIntentPrefetch } from './features/prefetch.js';
import { initializeHeroSlider } from './features/hero-slider.js';

initializeStorefront();
applyLocalContent();
enableIntentPrefetch();

initializeHeroSlider();
