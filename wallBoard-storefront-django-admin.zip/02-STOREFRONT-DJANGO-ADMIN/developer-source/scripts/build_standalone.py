#!/usr/bin/env python3
"""Build the npm-free preview from the editable source project.

Run from the packaged wallBoard repository root:
    python developer-source/scripts/build_standalone.py
"""
from pathlib import Path
import runpy

entry = Path(__file__).resolve().parents[2] / 'tools' / 'build_standalone.py'
runpy.run_path(str(entry), run_name='__main__')
