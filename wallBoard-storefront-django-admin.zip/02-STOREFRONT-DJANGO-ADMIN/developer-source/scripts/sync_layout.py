#!/usr/bin/env python3
"""Synchronize server-rendered static shell HTML without JS layout shifts.

Update templates/site-header.html or templates/site-footer.html, then run this script.
Each HTML output keeps its own current navigation state for accessibility.
"""
from pathlib import Path
from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parents[1]
HEADER = (ROOT / 'templates/site-header.html').read_text(encoding='utf-8')
FOOTER = (ROOT / 'templates/site-footer.html').read_text(encoding='utf-8')
PAGES = [
    'index', 'shop', 'product', 'categories', 'cart', 'checkout',
    'favorites', 'about', 'gallery', 'faq', 'contact',
]

for page in PAGES:
    source = ROOT / f'{page}.html'
    soup = BeautifulSoup(source.read_text(encoding='utf-8'), 'html.parser')
    fragment = BeautifulSoup(HEADER, 'html.parser')

    for link in fragment.select('.nav-link[href]'):
        classes = [item for item in link.get('class', []) if item != 'current']
        if link['href'] == f'{page}.html':
            classes.append('current')
            link['aria-current'] = 'page'
        elif link.has_attr('aria-current'):
            del link['aria-current']
        link['class'] = classes

    old_strip = soup.select_one('.top-strip')
    old_header = soup.select_one('.site-header')
    old_mobile = soup.select_one('.mobile-nav')
    new_strip = fragment.select_one('.top-strip')
    new_header = fragment.select_one('.site-header')
    new_mobile = fragment.select_one('.mobile-nav')
    old_strip.replace_with(new_strip)
    old_header.replace_with(new_header)
    old_mobile.replace_with(new_mobile)
    soup.select_one('.site-footer').replace_with(BeautifulSoup(FOOTER, 'html.parser').select_one('footer'))
    source.write_text('<!DOCTYPE html>\n' + soup.prettify(formatter='html'), encoding='utf-8')

print(f'Synchronized layout in {len(PAGES)} storefront pages.')
