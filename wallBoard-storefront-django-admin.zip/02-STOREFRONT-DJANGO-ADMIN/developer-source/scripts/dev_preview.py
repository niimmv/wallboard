#!/usr/bin/env python3
"""Run the source project WITHOUT npm, for local visual QA only.

Vite is still required for production build, hashed assets and bundle optimization.
"""
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from sys import argv

ROOT = Path(__file__).resolve().parents[1]
PORT = int(argv[1]) if len(argv) > 1 else 5500

class PreviewHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def translate_path(self, path):
        if path.startswith('/images/') or path in {'/site.webmanifest', '/robots.txt'}:
            return str(ROOT / 'public' / path.lstrip('/'))
        return super().translate_path(path)

    def end_headers(self):
        self.send_header('Cache-Control', 'no-cache')
        super().end_headers()

if __name__ == '__main__':
    print(f'Preview: http://localhost:{PORT}/index.html')
    if (ROOT / 'admin/index.html').exists():
        print(f'Admin preview: http://localhost:{PORT}/admin/index.html')
    else:
        print('Admin: use Django Admin in the connected backend.')
    ThreadingHTTPServer(('127.0.0.1', PORT), PreviewHandler).serve_forever()
