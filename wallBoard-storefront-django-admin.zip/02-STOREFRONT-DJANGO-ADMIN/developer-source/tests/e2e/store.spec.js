import { test, expect } from '@playwright/test';

test('Home is visible without hidden hero content', async ({ page }) => {
  await page.goto('/index.html');
  await expect(page.locator('.hero-carousel .hero-slide:not([hidden]) h1')).toBeVisible();
  await expect(page.locator('.brand')).toBeVisible();
});

test('a product can move from the shop to the cart', async ({ page }) => {
  await page.goto('/shop.html');
  await page.locator('[data-add="panel-30"]').click();
  await page.goto('/cart.html');
  await expect(page.locator('#cartItems')).toContainText('پنل پگ‌برد');
});

test('Home carousel keeps one slide visible and navigation works', async ({ page }) => {
  await page.goto('/index.html');

  const activeSlide = page.locator('.hero-slide:not([hidden])');
  await expect(activeSlide).toHaveCount(1);
  await expect(activeSlide).toHaveAttribute('id', 'heroSlideOne');

  await page.getByRole('button', { name: 'بنر بعدی' }).click();
  await expect(activeSlide).toHaveAttribute('id', 'heroSlideTwo');

  await page.getByRole('button', { name: 'رفتن به بنر سوم' }).click();
  await expect(activeSlide).toHaveAttribute('id', 'heroSlideThree');

  await page.getByRole('button', { name: 'توقف پخش خودکار' }).click();
  await expect(page.locator('[data-hero-pause]')).toHaveAttribute('aria-pressed', 'true');
});

test('Home banner fits narrow mobile screens', async ({ page }) => {
  await page.setViewportSize({ width: 320, height: 720 });
  await page.goto('/index.html');

  await expect(page.locator('.hero-carousel')).toBeVisible();

  const isOverflowing = await page.evaluate(() => {
    return document.documentElement.scrollWidth > window.innerWidth;
  });

  expect(isOverflowing).toBe(false);
});
