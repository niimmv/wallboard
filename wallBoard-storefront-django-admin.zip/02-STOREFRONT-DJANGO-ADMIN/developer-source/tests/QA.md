# Quality Assurance — Storefront Only

- [x] No custom admin HTML, JavaScript, CSS or bundle is included.
- [x] Product fixtures retain null price and stock until confirmation.
- [x] Product links use stable SEO slugs.
- [x] Django adapter includes same-origin credentials and CSRF header support.
- [x] Hero slider configured for 5-second rotation.

Required on developer workstation:
- [ ] `npm install`
- [ ] `npm run lint`
- [ ] `npm run test`
- [ ] `npm run build`
- [ ] `npm run budget`
- [ ] `npm run test:e2e`
- [ ] Test 320–1920 px viewports on Home, Shop, Product, Cart, Checkout and Account.
- [ ] Lighthouse mobile/desktop and real-device QA.
- [ ] Connect Django sessions, CSRF, catalog, cart, orders, media and payment.
- [ ] Verify all production metadata, canonical URLs, sitemap and Product JSON-LD.
