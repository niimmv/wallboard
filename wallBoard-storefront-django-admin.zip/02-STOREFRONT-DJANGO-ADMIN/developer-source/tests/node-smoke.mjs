/** Run without npm: `node tests/node-smoke.mjs` */
import assert from 'node:assert/strict';
import { listProducts, saveProducts, getProduct } from '../src/services/catalog.js';
import { getCart, changeCartQuantity, removeCartItem, cartTotal } from '../src/services/cart.js';
import { getFavorites, toggleFavorite } from '../src/services/favorites.js';
import { createDjangoApi } from '../src/services/django-api.js';

const memory = new Map();

globalThis.window = {
  localStorage: {
    getItem: (key) => memory.get(key) ?? null,
    setItem: (key, value) => memory.set(key, value),
    removeItem: (key) => memory.delete(key),
  },
  dispatchEvent: () => {},
};

globalThis.CustomEvent = class CustomEvent {
  constructor(type, options = {}) {
    this.type = type;
    this.detail = options.detail;
  }
};

const catalog = listProducts();
assert.ok(catalog.length >= 6);
assert.equal(getProduct('panel-30').price, null);
assert.equal(getProduct('pegboard-panel-30x30').id, 'panel-30');
assert.equal(getProduct('panel-30').stock, null);
assert.equal(getProduct('panel-30').specs.some((item) => item.includes('۸')), true);
assert.ok(Array.isArray(getProduct('panel-30').images));

assert.equal(changeCartQuantity('panel-30', 1), true);
assert.equal(getCart()['panel-30'], 1);
assert.equal(cartTotal().pricesComplete, false);
changeCartQuantity('panel-30', 4);
assert.equal(getCart()['panel-30'], 5);
removeCartItem('panel-30');
assert.equal(getCart()['panel-30'], undefined);

assert.equal(toggleFavorite('panel-30'), true);
assert.ok(getFavorites().includes('panel-30'));
assert.equal(toggleFavorite('panel-30'), false);
assert.ok(!getFavorites().includes('panel-30'));

const changed = structuredClone(catalog);
changed[0].images = ['/images/panel-front.webp', '/images/panel-side.webp'];
changed[0].price = 1000000;
assert.equal(saveProducts(changed), true);
assert.equal(getProduct('panel-30').images.length, 2);
assert.equal(getProduct('panel-30').price, 1000000);

const api = createDjangoApi();
assert.equal(typeof api.products.list, 'function');
assert.equal(typeof api.checkout.initialize, 'function');

const apiCalls = [];
const mockApi = createDjangoApi({
  basePath: '/api/v1',
  csrfToken: () => 'csrf-test-token',
  fetchImpl: async (url, options) => {
    apiCalls.push({ url, options });
    return new Response(JSON.stringify({ results: [] }), {
      status: 200,
      headers: { 'content-type': 'application/json' },
    });
  },
});
await mockApi.products.list({ page: 2, category: 'panels' });
await mockApi.orders.create({ items: [{ product_id: 'panel-30', quantity: 1 }] });
assert.match(apiCalls[0].url, /page=2.*category=panels|category=panels.*page=2/);
assert.equal(apiCalls[1].options.headers['X-CSRFToken'], 'csrf-test-token');
assert.equal(apiCalls[1].options.credentials, 'same-origin');

console.log('PASS: catalog, image paths, cart, favorites, and Django API adapter contracts.');
