# wallBoard — Storefront Only (Django Admin)

این توزیع هیچ پنل مدیریتی اختصاصی در فرانت‌اند ندارد. برای مدیریت واقعی محصولات، تصاویر، دسته‌ها، موجودی، سفارش‌ها، کاربران و بنرها از Django Admin استفاده کنید.

## اجرا

```bash
npm install
npm run dev
```

پیش‌نمایش مستقل بدون npm: از ریشه ZIP فایل `RUN-WALLBOARD-WINDOWS.bat` را اجرا کنید.

## ساختار

- `src/data/products.js`: داده‌های نمایشی؛ قیمت و موجودی نامشخص `null` هستند.
- `src/services/catalog.js`: مدل کاتالوگ و lookup با ID یا slug.
- `src/services/django-api.js`: قرارداد پیشنهادی اتصال DRF؛ هنوز به بک‌اند واقعی وصل نیست.
- `src/components/product.js`: کارت و گالری محصولات.
- `src/features/storefront.js`: تعاملات فروشگاه.
- `src/styles/tokens.css`: رنگ و تایپوگرافی مرکزی.
- `src/styles/responsive-polish.css`: بهینه‌سازی موبایل و touch targets.

## Backend

از Django Admin برای مدیریت استفاده کنید و `/admin/` را به Django route کنید. قبل از اتصال API، `../docs/DJANGO-BACKEND-HANDOFF.md` و `../docs/API-CONTRACT.md` را بخوانید.
