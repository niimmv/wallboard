#!/usr/bin/env python3
"""Static checks for the independent build, no npm or third-party packages."""
from __future__ import annotations

import re
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote, urlsplit

ROOT = Path(__file__).resolve().parents[1]
SITE = ROOT / 'site'


class AssetParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []
        self.errors = []
        self.tags = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        self.tags.append(tag)
        if tag == 'a' and 'href' not in attrs:
            self.errors.append('anchor without href')
        if tag == 'img' and 'alt' not in attrs:
            self.errors.append('image missing alt')
        for field in (('href',) if tag in ('a', 'link') else ('src',) if tag in ('img', 'script') else ()): 
            if field in attrs:
                self.links.append((tag, attrs[field]))


def run():
    errors = []
    pages = sorted(SITE.rglob('*.html'))
    for html in pages:
        text = html.read_text(encoding='utf-8')
        if text.lower().count('<!doctype html>') != 1:
            errors.append(f'{html}: invalid doctype count')
        parser = AssetParser()
        parser.feed(text)
        errors.extend(f'{html}: {message}' for message in parser.errors)
        for tag, raw_url in parser.links:
            url = urlsplit(raw_url)
            if url.scheme in ('http', 'https', 'mailto', 'tel', 'data') or raw_url.startswith('#'):
                continue
            if url.scheme or raw_url.startswith('//'):
                continue
            relative = unquote(url.path)
            if not relative or relative == '/':
                continue
            destination = (html.parent / relative).resolve()
            if not destination.is_relative_to(SITE.resolve()) or not destination.is_file():
                errors.append(f'{html.relative_to(SITE)} missing {tag}: {raw_url}')
        if html.relative_to(SITE).parts[0] != 'admin' and 'lang="fa"' not in text:
            errors.append(f'{html}: missing Persian language')
    assert not errors, '\n'.join(errors)
    print(f'PASS: {len(pages)} HTML pages, links/assets, language, doctype, alt text.')


if __name__ == '__main__':
    run()
