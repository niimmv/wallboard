#!/usr/bin/env python3
"""Optional browser QA, requires playwright and Chromium (not needed to run the store)."""
from __future__ import annotations

from contextlib import contextmanager
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from threading import Thread

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
SITE = ROOT / 'site'

@contextmanager
def preview_server():
    class QuietHandler(SimpleHTTPRequestHandler):
        def log_message(self, *_args):
            pass

    server = ThreadingHTTPServer(('127.0.0.1', 0), partial(QuietHandler, directory=str(SITE)))
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield f'http://127.0.0.1:{server.server_port}'
    finally:
        server.shutdown()
        server.server_close()


def run():
    with preview_server() as origin, sync_playwright() as pw:
        browser = pw.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
        context = browser.new_context(viewport={'width': 1440, 'height': 900}, reduced_motion='reduce')
        page = context.new_page()
        exceptions = []
        page.on('pageerror', lambda error: exceptions.append(str(error)))

        pages = [
            'index', 'shop', 'product', 'categories', 'cart', 'checkout', 'favorites',
            'about', 'gallery', 'faq', 'contact', 'account', 'shipping', 'returns',
            'privacy', 'terms',
        ]

        for name in pages:
            response = page.goto(f'{origin}/{name}.html', wait_until='domcontentloaded')
            assert response.ok, name
            assert page.locator('main').count() == 1, name
            assert page.locator('h1').count() > 0 or name == 'product', name
        print(f'Passed: {len(pages)} storefront pages')

        has_admin = (SITE / 'admin/index.html').exists()
        if has_admin:
            response = page.goto(f'{origin}/admin/index.html', wait_until='domcontentloaded')
            assert response.ok
            assert page.locator('#view').count() == 1
            print('Passed: optional admin preview entry')

        page.goto(f'{origin}/index.html', wait_until='domcontentloaded')
        assert page.locator('.hero-slide:not([hidden])').count() == 1
        assert page.locator('.hero-slide h1').is_visible()
        page.locator('[data-hero-next]').click()
        assert page.locator('.hero-slide:not([hidden])').get_attribute('id') == 'heroSlideTwo'
        page.locator('[data-hero-dot="2"]').click()
        assert page.locator('.hero-slide:not([hidden])').get_attribute('id') == 'heroSlideThree'
        print('Passed: hero interactions')

        page.goto(f'{origin}/shop.html', wait_until='domcontentloaded')
        assert page.locator('.product-card').count() >= 5
        assert page.locator('.product-card > p').count() == 0
        page.locator('#productSearch').fill('پنل')
        assert page.locator('.product-card').count() > 0
        page.locator('#productSearch').fill('')
        page.locator('[data-add="panel-30"]').click()
        page.goto(f'{origin}/cart.html', wait_until='domcontentloaded')
        assert 'پنل پگ‌برد' in page.locator('#cartItems').inner_text()
        print('Passed: shop, search and cart')

        page.goto(f'{origin}/product.html?id=panel-30', wait_until='domcontentloaded')
        assert page.locator('.detail-accordions details').count() == 3
        assert 'PVC' in page.locator('#productDetail').inner_text()
        print('Passed: product details')

        if has_admin:
            page.goto(f'{origin}/admin/index.html#products', wait_until='domcontentloaded')
            page.locator('[data-edit="products"][data-id="panel-30"]').click()
            page.locator('#admin-field-name').fill('پنل نهایی wallBoard')
            page.locator('#entityForm button[type="submit"]').click()
            page.goto(f'{origin}/shop.html', wait_until='domcontentloaded')
            assert 'پنل نهایی wallBoard' in page.locator('#productGrid').inner_text()
            print('Passed: optional admin edits reflected in storefront')

        for width in [320, 360, 375, 390, 414, 430, 768, 1024, 1280, 1440, 1920]:
            page.set_viewport_size({'width': width, 'height': 900})
            for name in ['index', 'shop', 'product', 'checkout', 'cart', 'account']:
                page.goto(f'{origin}/{name}.html', wait_until='domcontentloaded')
                page.wait_for_timeout(90)
                metric = page.evaluate('({ doc: document.documentElement.scrollWidth, viewport: window.innerWidth })')
                assert metric['doc'] <= metric['viewport'] + 2, (name, width, metric)
        print('Passed: mobile/tablet/desktop widths on six key pages')

        assert not exceptions, exceptions
        print('Passed: no JavaScript uncaught errors')
        browser.close()

if __name__ == '__main__':
    run()
