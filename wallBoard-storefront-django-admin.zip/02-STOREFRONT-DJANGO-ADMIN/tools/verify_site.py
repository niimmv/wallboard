#!/usr/bin/env python3
"""Static verification for the standalone wallBoard distribution."""
from __future__ import annotations

import re
import sys
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote, urlsplit

SITE = Path(__file__).resolve().parents[1] / 'site'
PAGES = sorted(SITE.rglob('*.html'))


class ResourceParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.resources = []

    def handle_starttag(self, tag, attrs):
        values = dict(attrs)
        attribute = 'href' if tag in {'a', 'link'} else 'src' if tag in {'script', 'img'} else None
        if attribute is not None and values.get(attribute):
            self.resources.append((tag, values[attribute]))


def main():
    errors = []
    expected_pages = 16 + int((SITE / 'admin/index.html').exists())
    if len(PAGES) != expected_pages:
        errors.append(f'Expected {expected_pages} HTML pages for this distribution, got {len(PAGES)}')

    for html in PAGES:
        raw = html.read_text(encoding='utf-8')
        if raw.lower().count('<!doctype html>') != 1:
            errors.append(f'{html}: invalid DOCTYPE count')
        parser = ResourceParser()
        parser.feed(raw)
        for tag, raw_ref in parser.resources:
            target_url = urlsplit(raw_ref)
            if target_url.scheme or raw_ref.startswith('//') or raw_ref.startswith('#'):
                continue
            if not target_url.path:
                continue
            path = unquote(target_url.path)
            if path.startswith('/'):
                errors.append(f'{html.name}: absolute reference {raw_ref}')
                continue
            target = (html.parent / path).resolve()
            if SITE.resolve() not in target.parents and target != SITE.resolve():
                errors.append(f'{html.name}: escapes site root: {raw_ref}')
            elif not target.exists():
                errors.append(f'{html.name}: missing {raw_ref}')
        if 'type="module"' in raw:
            errors.append(f'{html.name}: unbundled module entrypoint found')

    required_bundles = ['store.js', 'auth.js']
    if (SITE / 'admin/index.html').exists():
        required_bundles.append('admin.js')
    for filename in required_bundles:
        script = SITE / 'assets/js' / filename
        if not script.exists() or script.stat().st_size == 0:
            errors.append(f'Empty or missing {filename}')

    if errors:
        print('\n'.join('ERROR: ' + message for message in errors), file=sys.stderr)
        raise SystemExit(1)
    print(f'PASS: {len(PAGES)} pages, all local linked resources resolve, {len(required_bundles)} bundles present')


if __name__ == '__main__':
    main()
