# wallBoard — Storefront Only / Django Admin

این نسخه عمداً فاقد پنل مدیریت اختصاصی فرانت‌اند است. مدیریت محصولات، دسته‌بندی‌ها، رسانه، موجودی، سفارش‌ها و کاربران باید از **Django Admin** انجام شود.

## اجرا
1. ZIP را کامل استخراج کنید.
2. `RUN-WALLBOARD-WINDOWS.bat` را اجرا کنید.
3. صفحه اصلی در مرورگر باز می‌شود.

برای توسعه: `cd developer-source` سپس `npm install` و `npm run dev`.

## محتویات
- `site/`: پیش‌نمایش مستقل
- `developer-source/`: سورس HTML/CSS/JS + Vite
- `docs/DJANGO-BACKEND-HANDOFF.md`: راهنمای اتصال Django
- `docs/API-CONTRACT.md`: قرارداد پیشنهادی DRF
- `docs/SEO-HANDOFF.md`: تحویل به متخصص SEO
- `docs/ASSET-GUIDE.md`: افزودن تصاویر واقعی

## نکته امنیتی
این نسخه برای اتصال به Django طراحی شده، اما بک‌اند داخل ZIP نیست. تا زمان پیاده‌سازی، قیمت، موجودی، ورود، سفارش و پرداخت واقعی فعال نیستند. مسیر `/admin/` در نمونه Nginx به Django proxy می‌شود.

رنگ اصلی: `#FF636C` | اسلایدر Home: هر ۵ ثانیه
