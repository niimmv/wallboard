#!/bin/sh
cd "$(dirname "$0")" || exit 1
if command -v python3 >/dev/null 2>&1; then
  python3 run_server.py
elif command -v python >/dev/null 2>&1; then
  python run_server.py
else
  echo "Python 3 is needed. Install Python 3 and run this launcher again."
  exit 1
fi
